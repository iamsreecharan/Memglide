# Memglide daily A/B: sealed baseline evidence

This bundle contains 20 Python/TypeScript tasks, two repeats, two configurations: 80 original runs and 40 verified pairs. All completed successfully. The measured Memglide treatment is the legacy source-suffix preload format frozen at `6f4b6f6be83a7ad58ffba5f6c2176a9cc5d36dff`. It contains no compact-prefix/cache-format-v2 follow-up experiment data.

Start with [the assessment](benchmarks/daily-ab-assessment.md), [the full primary report](benchmarks/codex-ab-daily.md), and [the protocol](benchmarks/daily-protocol.md). Individual native JSONL streams, protected grader outcomes, earlier development failures, research access failures, and validation logs are included under `benchmarks/evidence/daily-ab-v1/`.

Results are mixed: aggregate uncached input rose 27.14%, while full execution time changed -4.76%. Both configurations passed all 40 tasks/repeats. Actual billing and cost per successful task are unavailable; no money-saving claim is established. Consult individual and paired results rather than interpreting aggregate token reduction as a billing result.

B uses preloaded context via private stdin, with no configured MCP tools. The common `prompt.txt` is not the full B native stdin body; private stdin was not persisted. Hashes, byte counts, source ranges and native arguments are retained in preparation metadata. Model-call totals, exact repeated filesystem reads, and provider billing remain unavailable where the reports say null.

Research, preparation profiling, read diagnostics and 817 preformal validation cases are separate supporting evidence, not additional A/B model runs. Frozen architecture/preload docs and benchmark source come from the Git commit above, not the later working tree. The assessment discusses later unmeasured refinements explicitly as future work.

`MEMBER-MANIFEST.json` lists every other ZIP member's byte count, SHA-256 and origin. Its own hash and the whole ZIP hash are in the external `benchmarks/daily-report-bundle.json` receipt, avoiding a self-hash cycle. The immutable published evidence manifest is separately pinned to `b4acba0ad2a8d0845487b89085f948a87932b10af86d177e0ba5f72c47ed99b7`.

All selected original bytes were credential-scanned. Only the two exact frozen Python JUnit XML hashes have exceptions for seven proven synthetic testcase-name matches each, reverified against literal fixtures in the frozen Git source; all other original bytes were scanned. No credentials, databases, private state, worktrees, raw browser config, or earlier ZIP archives are included. Original XML bytes and all historical raw outcomes are preserved.
