# Memglide ten-task cost study: report and evidence

**The eight source-prepared tasks cost 4.43% more with Memglide in the native-reported estimate. The two exact-prompt bypass controls drive the aggregate 2.28% apparent saving. These measurements do not establish that Memglide reduces model cost.**

Every dollar figure is an **API-list-price equivalent**, not an actual invoice or subscription charge.

A is standard native Codex and B is production compact-prefix Memglide followed by the same native Codex. The study uses 10 fresh coding tasks (5 Python, 5 TypeScript), one balanced repeat, 20 original assignments, identical starting commits, prompts, model `gpt-6.1-sol`, effort and native options. Memglide adds full current focused source in 8 B tasks and forwards the exact common prompt for 2 supplied-context controls. There are no configured native MCP tools in either arm. The deterministic preparation uses no auxiliary model. This does not measure MCP retrieval, cross-session memory or large unfamiliar repositories.

Start with [the cost assessment](benchmarks/cost-assessment.md), [the raw primary report](benchmarks/codex-cost-ab.md), [pricing provenance](benchmarks/cost-pricing-research.md), and [the protocol](benchmarks/cost-protocol.md).

| Result | A: standard Codex | B: Memglide |
|---|---:|---:|
| Successful assignments | 10 | 10 |
| Attempted runs | 10 | 10 |
| Estimated USD, all attempts | 0.392268 | 0.383337 |
| Estimated USD per successful task | 0.039227 | 0.038334 |
| Eight source-prepared tasks: USD per success | 0.040305 | 0.042093 |
| Two exact-prompt controls: USD per success | 0.034912 | 0.023298 |

The source-prepared subset is **4.43% more expensive** in B. The two bypass controls are **33.27% cheaper** despite identical forwarded task/source bytes; this variation cannot be attributed to source preloading. No control or outlier is excluded.

Aggregate native-reported price-equivalent savings per successful task: **2.28%**; positive means B costs less. Independent worst-case possible cache-write attribution gives a **-15.47% to 16.99%** savings scenario range. This range is not a confidence interval or observed billing.

Official per-million USD rates read for the selected model and requested standard/default tier: ordinary uncached input $2.0, cached reads $0.1, cache writes $2.5, output $10.0. Each is an exclusive input category: `((I-C-W)*ordinary_rate + C*cached_rate + W*write_rate + O*output_rate)/1,000,000`. Reasoning output is already included in output. Never add cached input to total input or count reasoning twice. Native JSONL cache-write zero may reflect the upstream parser default rather than explicit provider zero, so both the native-reported point and write sensitivity are retained. Applicable tariff, realized tier, discounts and attributable charges remain unavailable.

The cost-per-success numerator includes every attempted original and supplemental run, including failures; the denominator is successful distinct assignments. Missing attempt usage keeps arm total/per-success unavailable rather than zero. Failed attempts retained: 0. The raw primary report keeps actual and computed cost fields null; the separately named assessment carries estimates and source hashes. Local measured CPU/RSS/time have no attributable dollar rate and are not fabricated into actual expenditure.

The ten tasks are small synthetic known-file work. There is one observation per arm per task; backend and operating-system caches are uncontrolled, with pair order balanced. These results do not establish savings for every coding workload or long-term memory. No outlier, failed run, earlier corpus-validation failure, blocked fetch or audit failure is removed. Read-command counts are heuristic intent proxies, not actual filesystem reads. Model-call counts and attributable remote resource use are unavailable.

The runtime audit passed 4,307 assertions. The final independent numeric comparison passed 348 assertions and binds the final assessment, primary report and pricing hashes. An earlier price-auditor relative-path failure, its correction and pre-final draft comparisons remain preserved; no measured task was rerun for those tooling fixes.

All 20 original native JSONL streams, exact common prompts, executed commands, preparation reports, external graders, patches, checkpoints, durable attempt/result seals and independent audit are under `benchmarks/evidence/cost-ab-v1/`. Private native state, auth, databases, worktrees, fixture repositories and untracked-file contents are excluded. The common prompt is not B's full forwarded stdin; exact forwarded hashes, byte counts, full-source attestations and independent source reconstruction provide the delivery proof.

The frozen implementation and selected runtime benchmark, grader, tests, pricing and protocol Git blobs from `c7be678ab52aa5dab1f2a03317e53f2f6b0e5168` are reference text under `frozen-source/`. The post-freeze estimator and accounting regression tests are separately identified under `accounting-source/`; those files were not used by the measured runtime and are not labelled frozen Git blobs. This is not a full runnable source checkout. Every earlier tracked benchmark and ZIP was compared byte-for-byte against the frozen commit and remains unchanged; historical ZIPs are not duplicated here.

To recalculate the numerical estimate from an extracted copy of this ZIP, first restore the explicitly named estimator text to its Python module path. Run these commands from the extracted archive root, using Python 3.11 or newer and a fresh output prefix:

```sh
cp accounting-source/benchmarks/estimate_cost.py.txt benchmarks/estimate_cost.py
python -m benchmarks.estimate_cost --report benchmarks/codex-cost-ab.json --pricing benchmarks/cost-pricing.json --events-root benchmarks/evidence/cost-ab-v1/formal/runs --output-prefix NEW_PREFIX
```

This uses the published native events and frozen pricing without making model requests or rerunning tasks. The generated numerical assessment has a new creation timestamp and omits the separately preserved descriptive interpretation added by `benchmarks/evidence/cost-ab-v1/reproduction/accounting-interpretation.py.txt`; compare its numerical fields and source hashes rather than expecting a byte-identical final assessment. The estimator text and every input have SHA-256 records in `MEMBER-MANIFEST.json`.

`MEMBER-MANIFEST.json` lists every other member's size, SHA-256 and origin. Its own hash, whole-ZIP SHA, byte count, exact-member, CRC and per-member checks are in the external `benchmarks/cost-report-bundle.json`, avoiding circular checksums. Evidence manifest SHA: `2da8dae7b573371ec31b1c4545371ddef21af12d2a4c92d9e9fd13a8565811d5`. Pinned scanner SHA: `c3a9900974d465863ddec9ead70b3d04c4d41b4fcf43b2d2b64fd8a8b2325e24`.

Every selected original byte is scanned for credential patterns. Any narrow synthetic XML match exception requires an exact original hash and a matching public frozen Git literal within an approved testcase-name span; all other XML bytes are scanned and original bytes remain unchanged. Pattern scanning cannot prove absence of every possible secret. Full external research bodies, raw environment/browser configuration, credentials, databases and native state are never selected.
