# Memglide bounded warm-memory evidence

Original frozen implementation: 58ba0545187dbfb5270df246109bb81295718063.
The original cohort has 216 assignments; 1 were attempted.
The native study stopped on authentication. Failed and unrun observations remain intact.
No warm-memory model-cost or speed improvement is established. Missing usage is unknown, not zero.

`study/` preserves original JSON/log/receipt bytes. `reports/` contains final public report copies.
`frozen-source/` contains public Git blobs at the implementation freeze. `validation/` contains
local tests and component receipts; intentional corpus baselines and the earlier failed test
are calibration/engineering evidence, never native benchmark results.
The final full Python XML includes only narrowly approved synthetic credential test-name
matches backed by the frozen public security test AST. That one public test source also
permits only matching credential-like bytes inside frozen string-literal AST spans.
The originals are preserved and every other byte was scanned.

There are 12 logical repositories and 36 independently frozen stage repositories.
`fixture-bundles/` includes all refs of each author-generated single-commit stage, with every
reachable text blob/commit scanned before bundling; no Git config, hooks or reflogs are copied.

Verify every member with MEMBER-MANIFEST.json and the external manifest's ZIP SHA256 before use.
`git bundle verify fixture-bundles/<task-id>.bundle` checks a bundle inside a temporary Git repo.
`git clone fixture-bundles/<task-id>.bundle <destination>` restores that stage's original commit/tree.

For an exact auditor rerun, use a disposable environment with the original artifact layout
`/workspace/Memglide/.local/warm-v1`. Copy `study/` contents there without modifying originals, and clone each
bundle into the repository path listed in study/metadata.json. Never overwrite a current study.
Run Python from frozen-source/:

    python -m benchmarks.audit_warm --report /workspace/Memglide/.local/warm-v1/report.json --artifact-root /workspace/Memglide/.local/warm-v1 --output /tmp/warm-audit-rerun

Original records retain absolute paths. The auditor rejects pointers outside its explicit root;
use the original layout rather than rewriting result records or rehashing their ledger.
No authentication or model requests are required for these checks.

Excluded: native/Codex state, authentication, device-login codes, environment dumps, worktrees,
databases/WAL/SHM, untracked tar archives, installed environments, caches and live credentials.
Pattern scanning is a precaution, not proof that every possible secret format can be detected.
