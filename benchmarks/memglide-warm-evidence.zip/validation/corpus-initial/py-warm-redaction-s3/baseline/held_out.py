import json,unittest
from redaction import redact_records as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        rows=[{"id":1,"token":"a"},{"id":2,"PASSWORD":"b"}]; self.assertEqual(core.redact_records(rows),[{"id":1,"token":"[redacted]"},{"id":2,"PASSWORD":"[redacted]"}]); self.assertEqual(rows,[{"id":1,"token":"a"},{"id":2,"PASSWORD":"b"}])

    def test_behavior_1(self):
        rows=[{"id":1},{"id":1},{"id":2}]; result=core.redact_records(rows); self.assertEqual(result,rows); self.assertIsNot(result,rows); self.assertTrue(all(a is not b for a,b in zip(result,rows)))

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
