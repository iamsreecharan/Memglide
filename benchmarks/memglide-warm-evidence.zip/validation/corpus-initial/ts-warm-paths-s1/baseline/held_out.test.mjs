import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-corpus-validation/ts-warm-paths-s1/repo/src/normalize_key.ts";
test("behavior-0",()=>{assert.equal(core.normalize_key("/a//./b/"),"a/b"); assert.equal(core.normalize_key("a\\b"),"a/b"); assert.throws(()=>core.normalize_key("a/../b"));});
test("behavior-1",()=>{assert.equal(core.normalize_key("/Ä/%2e%2e/ a /"),"Ä/%2e%2e/ a "); assert.equal(core.normalize_key("././"),""); assert.throws(()=>core.normalize_key(".."));});
