import json,unittest
from retries import should_retry as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertTrue(core.should_retry(429,1,2)); self.assertFalse(core.should_retry(501,0,3)); self.assertFalse(core.should_retry(599,0,3))

    def test_behavior_1(self):
        self.assertFalse(core.should_retry(503,3,3)); self.assertFalse(core.should_retry(500,0,0)); self.assertTrue(core.should_retry(504,2,3))

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
