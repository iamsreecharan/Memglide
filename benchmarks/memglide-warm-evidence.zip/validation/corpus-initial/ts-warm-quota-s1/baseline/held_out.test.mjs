import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-corpus-validation/ts-warm-quota-s1/repo/src/remaining_quota.ts";
test("behavior-0",()=>{assert.equal(core.remaining_quota(5,9),0); assert.equal(core.remaining_quota(0,1),0);});
test("behavior-1",()=>{assert.equal(core.remaining_quota(0,0),0); assert.equal(core.remaining_quota(1000,999),1);});
