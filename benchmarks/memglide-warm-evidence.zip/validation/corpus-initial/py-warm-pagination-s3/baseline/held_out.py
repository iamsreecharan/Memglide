import json,unittest
from pagination import paginate as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.paginate([1,2,3,4,5],2),[[1,2],[3,4],[5]])

    def test_behavior_1(self):
        values=["a","a","b"]; before=list(values); result=core.paginate(values,1); self.assertEqual(result,[["a"],["a"],["b"]]); self.assertEqual(values,before); result[0].append("z"); self.assertEqual(values,before)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
