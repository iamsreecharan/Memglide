import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-corpus-validation/ts-warm-versions-s1/repo/src/compare_versions.ts";
test("behavior-0",()=>{assert.equal(core.compare_versions("1.10","1.2"),1); assert.equal(core.compare_versions("01.2","1.2.0"),0); assert.equal(core.compare_versions("2","10"),-1);});
test("behavior-1",()=>{assert.equal(core.compare_versions("0.0.0","0"),0); assert.equal(core.compare_versions("1.0.0.1","1"),1); assert.equal(core.compare_versions("9007199254740993","9007199254740992"),1);});
