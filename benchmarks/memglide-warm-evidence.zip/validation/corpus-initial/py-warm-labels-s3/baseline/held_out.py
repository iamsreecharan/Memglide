import json,unittest
from labels import label_lookup as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.label_lookup([(" A__B ",1),("a-b",2),("",3)]), {"a-b":2})

    def test_behavior_1(self):
        rows=[("B",1),("a",2),("b",3)]; before=list(rows); result=core.label_lookup(rows); self.assertEqual(result,{"b":3,"a":2}); self.assertEqual(list(result),["b","a"]); self.assertEqual(rows,before)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
