import json,unittest
from priority import priority_rank as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.priority_rank("unknown"),3); self.assertEqual(core.priority_rank("URGENT"),3)

    def test_behavior_1(self):
        self.assertEqual(core.priority_rank("normal"),1); self.assertEqual(core.priority_rank(""),3)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
