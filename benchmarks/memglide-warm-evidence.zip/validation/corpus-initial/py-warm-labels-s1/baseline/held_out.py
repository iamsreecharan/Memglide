import json,unittest
from labels import normalize_label as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.normalize_label(" A__--B\t"), "a-b"); self.assertEqual(core.normalize_label("ÄZ_雪"), "Äz-雪")

    def test_behavior_1(self):
        self.assertEqual(core.normalize_label("\u00a0AB\u00a0"), "\u00a0ab\u00a0"); self.assertEqual(core.normalize_label("a\tb"), "a\tb")

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
