import json,unittest
from labels import unique_labels as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.unique_labels([" A__B ","a-b","", " C "]), ["a-b","c"])

    def test_behavior_1(self):
        values=["ÄX","Äx","B","b"]; before=list(values); self.assertEqual(core.unique_labels(values), ["Äx","b"]); self.assertEqual(values,before)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
