import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-corpus-validation/ts-warm-clocks-s2/repo/src/format_clock.ts";
test("behavior-0",()=>{assert.equal(core.format_clock(0),"00:00"); assert.equal(core.format_clock(65),"01:05"); assert.equal(core.format_clock(600),"10:00");});
test("behavior-1",()=>{assert.equal(core.format_clock(9),"00:09"); assert.equal(core.format_clock(60),"01:00"); assert.equal(core.format_clock(1380),"23:00");});
