import json,unittest
from intervals import overlap_length as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.overlap_length((0,5),(2,7)),3); self.assertEqual(core.overlap_length((0,2),(2,4)),0)

    def test_behavior_1(self):
        self.assertEqual(core.overlap_length((-5,0),(-3,-1)),2); self.assertEqual(core.overlap_length((1,1),(0,3)),0)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
