import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-corpus-validation/ts-warm-headers-s1/repo/src/normalize_header.ts";
test("behavior-0",()=>{assert.equal(core.normalize_header(" \tX-Id\t "),"x-id"); assert.equal(core.normalize_header("Ä-ID"),"Ä-id");});
test("behavior-1",()=>{assert.equal(core.normalize_header("\nx-id\n"),"\nx-id\n"); assert.equal(core.normalize_header("X Id"),"x id");});
