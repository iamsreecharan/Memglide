import json,unittest
from redaction import redact_record as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        row={"Token":"a","id":1,"SECRET":"b"}; self.assertEqual(core.redact_record(row),{"Token":"[redacted]","id":1,"SECRET":"[redacted]"}); self.assertEqual(row,{"Token":"a","id":1,"SECRET":"b"})

    def test_behavior_1(self):
        row={"password_hint":"keep","password":None}; result=core.redact_record(row); self.assertEqual(result,{"password_hint":"keep","password":"[redacted]"}); self.assertIsNot(result,row)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
