import json,unittest
from pagination import page_window as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.page_window(12,5,1),(5,10)); self.assertEqual(core.page_window(12,5,2),(10,12))

    def test_behavior_1(self):
        self.assertEqual(core.page_window(8,3,99),(8,8)); self.assertEqual(core.page_window(6,3,1),(3,6))

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
