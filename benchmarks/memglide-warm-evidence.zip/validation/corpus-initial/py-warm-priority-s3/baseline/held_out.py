import json,unittest
from priority import next_job as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        rows=[{"name":"n","priority":"normal"},{"name":"u","priority":"urgent"},{"name":"v","priority":"urgent"}]; self.assertEqual(core.next_job(rows)["name"],"u")

    def test_behavior_1(self):
        rows=[{"name":"u","priority":"urgent","done":True},{"name":"n","priority":"normal"}]; before=[dict(r) for r in rows]; self.assertEqual(core.next_job(rows)["name"],"n"); self.assertEqual(rows,before); self.assertIsNone(core.next_job([rows[0]]))

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
