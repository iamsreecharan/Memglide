import json,unittest
from retries import retry_delays as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.retry_delays(3,5,20),[3,6,12,20,20])

    def test_behavior_1(self):
        self.assertEqual(core.retry_delays(1,1,99),[1]); self.assertEqual(core.retry_delays(7,4,7),[7,7,7,7])

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
