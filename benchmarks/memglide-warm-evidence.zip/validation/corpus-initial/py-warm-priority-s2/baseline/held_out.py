import json,unittest
from priority import order_jobs as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        rows=[{"name":"z","priority":"normal"},{"name":"a","priority":"normal"},{"name":"u","priority":"urgent"}]; self.assertEqual([r["name"] for r in core.order_jobs(rows)],["u","z","a"])

    def test_behavior_1(self):
        rows=[{"name":"z","priority":"other"},{"name":"a","priority":"other"}]; before=[dict(r) for r in rows]; self.assertEqual(core.order_jobs(rows),before); self.assertEqual(rows,before); self.assertIsNot(core.order_jobs(rows),rows)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
