import json,unittest
from intervals import contains_point as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertFalse(core.contains_point((0,3),3)); self.assertFalse(core.contains_point((2,2),2))

    def test_behavior_1(self):
        self.assertTrue(core.contains_point((-3,0),-1)); self.assertFalse(core.contains_point((-3,0),0))

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
