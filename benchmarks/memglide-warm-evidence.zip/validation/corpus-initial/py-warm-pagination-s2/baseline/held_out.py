import json,unittest
from pagination import page_count as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.page_count(7,3),3); self.assertEqual(core.page_count(1,8),1)

    def test_behavior_1(self):
        self.assertEqual(core.page_count(1001,10),101); self.assertEqual(core.page_count(10,1),10)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
