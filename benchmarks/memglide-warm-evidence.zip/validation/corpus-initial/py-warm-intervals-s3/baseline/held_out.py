import json,unittest
from intervals import merge_ranges as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.merge_ranges([(4,5),(0,2),(2,4),(3,3)]),[(0,5)])

    def test_behavior_1(self):
        rows=[(5,9),(-2,0),(7,8)]; before=list(rows); self.assertEqual(core.merge_ranges(rows),[(-2,0),(5,9)]); self.assertEqual(rows,before)

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
