import json,unittest
from redaction import redact_field as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertEqual(core.redact_field("ToKeN","x"),"[redacted]"); self.assertEqual(core.redact_field("PASSWORD",42),"[redacted]")

    def test_behavior_1(self):
        self.assertEqual(core.redact_field("secret_hint","keep"),"keep"); self.assertIsNone(core.redact_field("id",None)); self.assertEqual(core.redact_field(" Secret ","keep"),"keep")

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
