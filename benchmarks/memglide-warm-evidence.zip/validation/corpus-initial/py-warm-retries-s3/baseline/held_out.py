import json,unittest
from retries import next_delay as core

class BehaviorTests(unittest.TestCase):
    def test_behavior_0(self):
        self.assertIsNone(core.next_delay(200,0,3,2,20)); self.assertIsNone(core.next_delay(503,3,3,2,20))

    def test_behavior_1(self):
        self.assertEqual(core.next_delay(429,2,4,3,10),10); self.assertIsNone(core.next_delay(501,0,5,1,10))

if __name__ == "__main__":
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(BehaviorTests))
    print("CORPUS_RESULT="+json.dumps({"tests":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped)}))
    raise SystemExit(not result.wasSuccessful())
