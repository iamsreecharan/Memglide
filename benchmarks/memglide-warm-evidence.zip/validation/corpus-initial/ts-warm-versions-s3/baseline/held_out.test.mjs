import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-corpus-validation/ts-warm-versions-s3/repo/src/newest_version.ts";
test("behavior-0",()=>{assert.equal(core.newest_version(["2","10","9"]),"10"); assert.equal(core.newest_version(["1.02","1.2","1.2.0"]),"1.02");});
test("behavior-1",()=>{const values=["01","1.0","0"]; const before=[...values]; assert.equal(core.newest_version(values),"01"); assert.deepEqual(values,before);});
