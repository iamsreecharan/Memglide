import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-corpus-validation/ts-warm-versions-s2/repo/src/sort_versions.ts";
test("behavior-0",()=>{assert.deepEqual(core.sort_versions(["1.10","1.2","1.02","1.2.0"]),["1.2","1.02","1.2.0","1.10"]);});
test("behavior-1",()=>{const values=["10","2","01","1.0"]; const before=[...values]; assert.deepEqual(core.sort_versions(values),["01","1.0","2","10"]); assert.deepEqual(values,before);});
