# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow.spec.ts >> production dashboard completes the repository, session, memory, retrieval, and evidence workflow
- Location: e2e/workflow.spec.ts:25:1

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Your first project starts here' })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Your first project starts here' }) with timeout 10000ms
  - waiting for getByRole('heading', { name: 'Your first project starts here' })

```

```yaml
- link "Skip to content":
  - /url: "#main"
- complementary:
  - link "Memglide overview":
    - /url: /
    - text: memglide. V1
  - text: WORKSPACE
  - navigation "Main navigation":
    - link "Overview":
      - /url: /
    - link "Projects":
      - /url: /projects
    - link "Memory explorer":
      - /url: /memory
    - link "Context explorer":
      - /url: /context
    - link "Context passport CORE":
      - /url: /passport
    - link "Session timeline":
      - /url: /timeline
    - link "Settings":
      - /url: /settings
  - strong: Local by design
  - paragraph: Your code stays on this machine.
  - link "API documentation":
    - /url: /docs
  - text: Local service connected v0.1.0
- banner:
  - text: Workspace
  - strong: Projects
  - text: Localhost
- text: PROJECT
- combobox "PROJECT":
  - option "auth-repository" [selected]
- text: SESSION
- combobox "SESSION":
  - option "Select a session" [selected]
- button "New session"
- main:
  - text: SOURCE INTELLIGENCE
  - heading "Projects" [level=1]
  - paragraph: Approve a local repository. Memglide indexes its structure without executing its code.
  - button "Add repository"
  - heading "auth-repository" [level=2]
  - paragraph: /workspace/Memglide/.local/e2e/run-devrNR/auth-repository
  - text: Selected Branch
  - strong: main
  - text: Indexed files
  - strong: "10"
  - text: Symbols
  - strong: "10"
  - text: Last indexed
  - strong: just now
  - text: python · 4 text · 3 tsx · 1 typescript · 2
  - button "Index details"
  - button "Reindex"
  - button "Remove auth-repository"
  - paragraph: Removing a registration deletes its local index and task data. It never deletes repository files.
- contentinfo: MEMGLIDE / LOCAL CONTEXT INTELLIGENCE Remember. Select. Verify. Expand.
```

# Test source

```ts
  46  |   await page.getByRole('button', { name: 'Reindex', exact: true }).click()
  47  |   await expect(page.getByRole('status')).toContainText('Index updated')
  48  |   await page.getByRole('button', { name: 'New session' }).click()
  49  |   await page.getByLabel('Task', { exact: true }).fill('Investigate authentication boundaries')
  50  |   await page.getByRole('button', { name: 'Start session', exact: true }).click()
  51  |   await expect(page.getByRole('dialog')).toHaveCount(0)
  52  |   await expect(page.getByLabel('SESSION', { exact: true })).toContainText('Investigate authentication boundaries')
  53  | 
  54  |   await navigate(page, 'Memory explorer')
  55  |   await expect(page.getByRole('heading', { name: 'A fresh session' })).toBeVisible()
  56  |   await page.getByRole('button', { name: 'Save a memory' }).first().click()
  57  |   await page.getByLabel('Category', { exact: true }).selectOption('verified_fix')
  58  |   await page.getByLabel('Finding', { exact: true }).fill('Bearer authentication rejects an unsupported scheme before token verification.')
  59  |   await page.getByLabel('Provenance', { exact: true }).fill('Inspected authenticate_user in api/auth.py and its structural callers.')
  60  |   await page.getByLabel('Related files (optional)').fill('api/auth.py')
  61  |   await page.getByRole('button', { name: 'Save memory', exact: true }).click()
  62  |   await expect(page.getByRole('dialog')).toHaveCount(0)
  63  |   await expect(page.locator('.memory-content')).toContainText('Bearer authentication rejects')
  64  |   await expect(page.locator('.memory-provenance')).toContainText('Inspected authenticate_user')
  65  |   await expect(page.locator('.memory-sources')).toContainText('api/auth.py')
  66  |   await expect(page.locator('.memory-sources [title]')).toHaveAttribute('title', /Source hash: [a-f0-9]{64}/)
  67  |   await page.getByRole('button', { name: /^Edit memory/ }).click()
  68  |   await expect(page.getByLabel('Finding', { exact: true })).toBeFocused()
  69  |   await page.getByLabel('Finding', { exact: true }).fill('Bearer authentication validates the scheme before delegating to verify_token.')
  70  |   await page.getByRole('button', { name: 'Save changes', exact: true }).click()
  71  |   await expect(page.locator('.memory-content')).toContainText('delegating to verify_token')
  72  |   await page.getByRole('textbox', { name: 'Search memories' }).fill('nonexistent-memory-phrase')
  73  |   await expect(page.getByRole('heading', { name: 'No matching memories' })).toBeVisible()
  74  |   await page.getByRole('button', { name: 'Clear filters' }).click()
  75  |   await expect(page.locator('.memory-content')).toContainText('delegating to verify_token')
  76  | 
  77  |   await navigate(page, 'Context explorer')
  78  |   await page.getByLabel('WHAT DO YOU NEED TO UNDERSTAND?').fill('authenticate_user verify_token')
  79  |   await page.getByLabel('Token budget', { exact: true }).fill('12000')
  80  |   await page.getByRole('button', { name: 'Retrieve context', exact: true }).click()
  81  |   await expect(page.locator('.evidence-card').first()).toBeVisible()
  82  |   await expect(page.locator('.results-heading')).toContainText('Level 1')
  83  |   await page.getByRole('button', { name: 'Expand to level 2' }).click()
  84  |   await expect(page.locator('.results-heading')).toContainText('Level 2')
  85  |   await expect(page.locator('.code-block').first()).toContainText(/def |function /)
  86  |   await page.getByRole('button', { name: 'Expand to level 3' }).click()
  87  |   await expect(page.locator('.results-heading')).toContainText('Level 3')
  88  |   await page.getByRole('link', { name: 'View passport' }).click()
  89  |   await expect(page.getByRole('heading', { name: 'Context passport', exact: true })).toBeVisible()
  90  |   await expect(page.locator('.passport-banner')).toContainText('evidence')
  91  |   await expect(page.locator('.hash-list')).toContainText('api/auth.py')
  92  |   await expect(page.getByRole('heading', { name: 'Related tests', exact: true })).toBeVisible()
  93  |   await page.getByRole('button', { name: 'Verify source versions' }).click()
  94  |   await expect(page.locator('.passport-banner')).toContainText('Current sources')
  95  | 
  96  |   await navigate(page, 'Session timeline')
  97  |   await expect(page.locator('.timeline-event')).not.toHaveCount(0)
  98  |   await page.getByLabel('Event type', { exact: true }).selectOption('memory_saved')
  99  |   await expect(page.locator('.timeline-event')).toHaveCount(1)
  100 |   await expect(page.locator('.timeline-event')).toContainText('Memory Saved')
  101 |   await page.getByRole('checkbox', { name: 'Selected session only' }).check()
  102 |   await page.getByRole('button', { name: 'Event details' }).click()
  103 |   await expect(page.locator('.timeline-event .detail-json')).toBeVisible()
  104 | 
  105 |   await navigate(page, 'Settings')
  106 |   await page.getByLabel('Inactivity timeout (minutes)').fill('45')
  107 |   await page.getByLabel('Default context token budget').fill('6000')
  108 |   await page.getByRole('button', { name: 'Light', exact: true }).click()
  109 |   await page.getByRole('button', { name: 'Save settings' }).click()
  110 |   await expect(page.getByRole('button', { name: 'Save settings' })).toBeDisabled()
  111 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'light')
  112 |   await page.reload()
  113 |   await expect(page.getByLabel('Inactivity timeout (minutes)')).toHaveValue('45')
  114 |   await expect(page.getByLabel('Default context token budget')).toHaveValue('6000')
  115 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'light')
  116 |   await page.getByRole('button', { name: 'Dark', exact: true }).click()
  117 |   await page.getByRole('button', { name: 'Save settings' }).click()
  118 |   await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')
  119 |   await page.getByRole('button', { name: 'Run diagnostics' }).click()
  120 |   await expect(page.locator('.maintenance-panel .detail-json')).toContainText('frontend_built')
  121 |   await page.getByRole('button', { name: 'Run cleanup' }).click()
  122 |   await expect(page.getByRole('status').filter({ hasText: 'Cleanup complete' })).toBeVisible()
  123 |   await navigate(page, 'Overview')
  124 |   await expect(page.locator('.metric-value').first()).toHaveText('1')
  125 |   await page.screenshot({ path: 'test-results/memglide-overview.png', fullPage: true })
  126 |   await assertNoOverflow(page)
  127 | 
  128 |   await navigate(page, 'Memory explorer')
  129 |   await page.getByRole('button', { name: /^Delete memory/ }).click()
  130 |   await page.getByRole('dialog').getByRole('button', { name: 'Cancel', exact: true }).click()
  131 |   await expect(page.locator('.memory-card')).toHaveCount(1)
  132 |   await page.getByRole('button', { name: /^Delete memory/ }).click()
  133 |   await page.getByRole('dialog').getByRole('button', { name: 'Delete memory', exact: true }).click()
  134 |   await expect(page.getByRole('heading', { name: 'A fresh session' })).toBeVisible()
  135 |   await page.getByRole('button', { name: 'End selected session' }).click()
  136 |   await page.getByRole('dialog').getByRole('button', { name: 'End session', exact: true }).click()
  137 |   await expect(page.getByRole('button', { name: 'Save a memory' }).first()).toBeDisabled()
  138 |   await expect(page.getByLabel('SESSION', { exact: true })).toContainText('Investigate authentication boundaries · ended')
  139 |   await navigate(page, 'Settings')
  140 |   await page.getByRole('button', { name: 'Delete session data', exact: true }).click()
  141 |   await page.getByRole('dialog').getByRole('button', { name: 'Delete session data', exact: true }).click()
  142 |   await expect(page.getByLabel('SESSION', { exact: true })).toHaveValue('')
  143 |   await navigate(page, 'Projects')
  144 |   await page.getByRole('button', { name: `Remove ${basename(projectPath())}` }).click()
  145 |   await page.getByRole('dialog').getByRole('button', { name: 'Remove project', exact: true }).click()
> 146 |   await expect(page.getByRole('heading', { name: 'Your first project starts here' })).toBeVisible()
      |                                                                                       ^ Error: expect(locator).toBeVisible() failed
  147 |   expect(errors).toEqual([])
  148 | })
  149 | 
  150 | test('background cleanup cannot redirect a session deletion confirmation to another task', async ({ page, request }) => {
  151 |   await clearProjects(request)
  152 |   const projectResponse = await request.post('/api/projects', { headers: mutationHeaders, data: { path: projectPath() } })
  153 |   expect(projectResponse.ok()).toBeTruthy()
  154 |   const project = await projectResponse.json() as { id: string }
  155 |   const sessionResponse = await request.post('/api/sessions', { headers: mutationHeaders, data: { project_id: project.id, task: 'Original deletion target' } })
  156 |   expect(sessionResponse.ok()).toBeTruthy()
  157 |   const original = await sessionResponse.json() as { id: string }
  158 |   const remainingResponse = await request.post('/api/sessions', { headers: mutationHeaders, data: { project_id: project.id, task: 'Keep this task' } })
  159 |   expect(remainingResponse.ok()).toBeTruthy()
  160 |   const remaining = await remainingResponse.json() as { id: string }
  161 |   await page.clock.install()
  162 |   await page.goto('/memory')
  163 |   await page.getByLabel('SESSION', { exact: true }).selectOption(original.id)
  164 |   await expect(page.getByLabel('SESSION', { exact: true })).toHaveValue(original.id)
  165 |   await page.getByRole('button', { name: 'Delete selected session and memory' }).click()
  166 |   await expect(page.getByRole('dialog')).toContainText('Original deletion target')
  167 |   expect((await request.post(`/api/sessions/${original.id}/clear`, { headers: mutationHeaders })).ok()).toBeTruthy()
  168 |   // Advance the normal polling interval, preserving the real request/response
  169 |   // path and avoiding a wall-clock sleep in the production browser test.
  170 |   await page.clock.fastForward(15_001)
  171 |   await expect(page.getByLabel('SESSION', { exact: true })).toHaveValue(remaining.id)
  172 |   await page.getByRole('dialog').getByRole('button', { name: 'Delete session', exact: true }).click()
  173 |   await expect(page.getByRole('dialog').getByRole('alert')).toContainText('Request could not be completed')
  174 |   const sessionsResponse = await request.get(`/api/sessions?project_id=${project.id}`)
  175 |   expect(sessionsResponse.ok()).toBeTruthy()
  176 |   expect((await sessionsResponse.json() as { id: string }[]).map(item => item.id)).toEqual([remaining.id])
  177 |   await expect(page.getByLabel('SESSION', { exact: true })).toHaveValue(remaining.id)
  178 | })
  179 | 
  180 | test('production routes retain useful empty and error states and fit desktop and tablet', async ({ page, request }) => {
  181 |   await clearProjects(request)
  182 |   const errors: string[] = []
  183 |   page.on('pageerror', error => errors.push(error.message))
  184 |   await page.goto('/passport')
  185 |   await expect(page.getByRole('heading', { name: 'Every retrieval gets a passport' })).toBeVisible()
  186 |   const projectResponse = await request.post('/api/projects', { headers: mutationHeaders, data: { path: projectPath() } })
  187 |   expect(projectResponse.ok()).toBeTruthy()
  188 |   const project = await projectResponse.json() as { id: string }
  189 |   const sessionResponse = await request.post('/api/sessions', { headers: mutationHeaders, data: { project_id: project.id, task: 'Review production dashboard responsiveness' } })
  190 |   expect(sessionResponse.ok()).toBeTruthy()
  191 |   const session = await sessionResponse.json() as { id: string }
  192 |   const anotherSessionResponse = await request.post('/api/sessions', { headers: mutationHeaders, data: { project_id: project.id, task: 'Compare active task workspaces' } })
  193 |   expect(anotherSessionResponse.ok()).toBeTruthy()
  194 |   const anotherSession = await anotherSessionResponse.json() as { id: string }
  195 |   await page.goto(`/passport?retrieval=missing-retrieval&session=${session.id}`)
  196 |   await expect(page.getByLabel('SESSION', { exact: true })).toHaveValue(session.id)
  197 |   await expect(page.getByRole('alert')).toContainText('Request could not be completed')
  198 |   await expect(page.getByRole('button', { name: 'Try again' })).toBeVisible()
  199 |   await page.goto('/context')
  200 |   await page.getByLabel('SESSION', { exact: true }).selectOption(anotherSession.id)
  201 |   await expect(page.getByLabel('SESSION', { exact: true })).toHaveValue(anotherSession.id)
  202 |   await page.getByLabel('SESSION', { exact: true }).selectOption(session.id)
  203 |   await expect(page.getByLabel('SESSION', { exact: true })).toHaveValue(session.id)
  204 |   await page.getByLabel('WHAT DO YOU NEED TO UNDERSTAND?').fill('zxqvnonexistent934712')
  205 |   await expect(page.getByRole('button', { name: 'Retrieve context', exact: true })).toBeEnabled()
  206 |   await page.getByRole('button', { name: 'Retrieve context', exact: true }).click()
  207 |   await expect(page.getByRole('heading', { name: 'No source evidence matched' })).toBeVisible()
  208 |   const routes = [
  209 |     ['/', 'Your context, in focus.'], ['/projects', 'Projects'], ['/memory', 'Memory explorer'],
  210 |     ['/context', 'Context explorer'], ['/passport', 'Context passport'], ['/timeline', 'Session timeline'], ['/settings', 'Settings'],
  211 |   ] as const
  212 |   for (const width of [1440, 1024, 768]) {
  213 |     await page.setViewportSize({ width, height: 1000 })
  214 |     for (const [path, heading] of routes) {
  215 |       await page.goto(path)
  216 |       await expect(page.getByRole('heading', { name: heading, exact: true })).toBeVisible()
  217 |       await expect(page.getByText('Localhost', { exact: true })).toBeVisible()
  218 |       await assertNoOverflow(page)
  219 |     }
  220 |   }
  221 |   await page.goto('/')
  222 |   await page.screenshot({ path: 'test-results/memglide-tablet.png', fullPage: true })
  223 |   expect(errors).toEqual([])
  224 | })
  225 | 
```