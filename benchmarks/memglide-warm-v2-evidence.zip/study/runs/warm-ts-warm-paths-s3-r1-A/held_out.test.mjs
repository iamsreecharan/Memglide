import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-paths-r1-A/src/parent_key.ts";
test("behavior-0",()=>{assert.equal(core.parent_key("/a//b/"),"a"); assert.equal(core.parent_key("a\\b\\c"),"a/b"); assert.throws(()=>core.parent_key("a/../b"));});
test("behavior-1",()=>{assert.equal(core.parent_key("././"),""); assert.equal(core.parent_key("/Ä/%2e%2e/file"),"Ä/%2e%2e");});
