import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-routing-r1-A/src/choose_route.ts";
test("behavior-0",()=>{const rows=[{name:"dynamic",pattern:"/:id"},{name:"literal",pattern:"/users"}]; assert.equal(core.choose_route(rows,"/users"),"dynamic"); assert.equal(core.choose_route(rows,"/none/extra"),null);});
test("behavior-1",()=>{const rows=[{name:"first",pattern:"/x"},{name:"last",pattern:"/x"}]; const before=JSON.stringify(rows); assert.equal(core.choose_route(rows,"/x"),"first"); assert.equal(JSON.stringify(rows),before);});
