import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-clocks-r1-A/src/window_contains.ts";
test("behavior-0",()=>{assert.equal(core.window_contains(60,120,120),false); assert.equal(core.window_contains(60,60,60),false); assert.equal(core.window_contains(1380,60,0),true);});
test("behavior-1",()=>{assert.equal(core.window_contains(1380,60,60),false); assert.equal(core.window_contains(1380,60,1380),true); assert.equal(core.window_contains(1380,60,800),false);});
