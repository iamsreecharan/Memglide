import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-quota-r1-B/src/allocate_batch.ts";
test("behavior-0",()=>{assert.deepEqual(core.allocate_batch(8,0,[9,3,6,5,0]),[1,3,4]); assert.deepEqual(core.allocate_batch(0,2,[1,0,0]),[1,2]);});
test("behavior-1",()=>{const rows=[7,2,1]; const before=[...rows]; assert.deepEqual(core.allocate_batch(4,0,rows),[1,2]); assert.deepEqual(rows,before);});
