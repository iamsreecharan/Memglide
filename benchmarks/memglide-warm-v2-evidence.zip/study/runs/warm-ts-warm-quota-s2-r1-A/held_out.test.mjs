import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-quota-r1-A/src/can_allocate.ts";
test("behavior-0",()=>{assert.equal(core.can_allocate(10,2,8),true); assert.equal(core.can_allocate(10,10,0),true); assert.equal(core.can_allocate(2,5,0),true);});
test("behavior-1",()=>{assert.equal(core.can_allocate(0,0,1),false); assert.equal(core.can_allocate(0,0,0),true);});
