import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-clocks-r1-A/src/parse_clock.ts";
test("behavior-0",()=>{assert.equal(core.parse_clock("23:59"),1439); for(const value of ["1:02","24:00","12:60"," 01:02","01:02x"]) assert.throws(()=>core.parse_clock(value));});
test("behavior-1",()=>{assert.equal(core.parse_clock("07:05"),425); for(const value of ["01:2","-1:00","","01:02\n"]) assert.throws(()=>core.parse_clock(value));});
