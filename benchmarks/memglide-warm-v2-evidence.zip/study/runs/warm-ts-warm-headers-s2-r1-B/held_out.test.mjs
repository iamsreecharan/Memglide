import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-headers-r1-B/src/header_values.ts";
test("behavior-0",()=>{assert.deepEqual(core.header_values([["X-ID"," a "],["x-id","b"],["other","c"],["x-id"," "]]," x-ID "),["a","b"]);});
test("behavior-1",()=>{const rows=[["X","a"],["x","a"],["x","\nb\n"]]; const before=JSON.stringify(rows); assert.deepEqual(core.header_values(rows,"x"),["a","a","\nb\n"]); assert.equal(JSON.stringify(rows),before);});
