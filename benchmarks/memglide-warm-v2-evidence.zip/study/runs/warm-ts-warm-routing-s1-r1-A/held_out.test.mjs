import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-routing-r1-A/src/segment_matches.ts";
test("behavior-0",()=>{assert.equal(core.segment_matches(":id","42"),true); assert.equal(core.segment_matches(":id",""),false); assert.equal(core.segment_matches("a.b","axb"),false);});
test("behavior-1",()=>{assert.equal(core.segment_matches("[id]","[id]"),true); assert.equal(core.segment_matches("Users","users"),false); assert.equal(core.segment_matches("a+b","a+b"),true);});
