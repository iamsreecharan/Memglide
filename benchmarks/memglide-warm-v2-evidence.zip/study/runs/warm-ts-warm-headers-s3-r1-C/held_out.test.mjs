import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-headers-r1-C/src/merge_header.ts";
test("behavior-0",()=>{assert.equal(core.merge_header([["X"," a "],["x","b"],["x","a"]],"x"),"a, b, a");});
test("behavior-1",()=>{const rows=[["x"," "],["other","z"],["X","b"]]; const before=JSON.stringify(rows); assert.equal(core.merge_header(rows," x "),"b"); assert.equal(JSON.stringify(rows),before);});
