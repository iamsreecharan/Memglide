import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-paths-r1-A/src/join_key.ts";
test("behavior-0",()=>{assert.equal(core.join_key("/a/","/./b/"),"a/b"); assert.equal(core.join_key("",""),""); assert.throws(()=>core.join_key("a","../b"));});
test("behavior-1",()=>{assert.equal(core.join_key("A\\B","C"),"A/B/C"); assert.equal(core.join_key("a","%2e%2e"),"a/%2e%2e");});
