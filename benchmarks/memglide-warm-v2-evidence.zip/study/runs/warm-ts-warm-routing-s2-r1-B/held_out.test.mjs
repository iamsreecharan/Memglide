import test from "node:test";
import assert from "node:assert/strict";
import * as core from "file:///workspace/Memglide/.local/warm-v2/worktrees/ts-warm-routing-r1-B/src/match_route.ts";
test("behavior-0",()=>{assert.equal(core.match_route("/users","/users/3"),false); assert.equal(core.match_route("/users/:id","/users"),false); assert.equal(core.match_route("//users//:id/","/users//3/"),true);});
test("behavior-1",()=>{assert.equal(core.match_route("/","/"),true); assert.equal(core.match_route("/","/users"),false); assert.equal(core.match_route("/a.b","/axb"),false);});
