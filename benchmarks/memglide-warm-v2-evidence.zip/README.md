# Memglide bounded warm-memory evidence

Original frozen implementation: 58ba0545187dbfb5270df246109bb81295718063.
The original cohort has 216 assignments; 81 were attempted.
Cohort: warm-v2. Failed, interrupted and unrun observations remain intact.
Measured outcomes and limitations appear in reports/. Missing usage is unknown, not zero;
partial coverage does not establish a universal cost or speed advantage.

`study/` preserves original JSON/log/receipt bytes. `reports/` contains final public report copies.
`frozen-source/` contains public Git blobs at the implementation freeze, including documentation
that still described the then-pending study. Current outcomes are in reports/, not those snapshots.
`validation/` contains
local tests and component receipts; intentional corpus baselines and the earlier failed test
are calibration/engineering evidence, never native benchmark results.
The final full Python XML includes only narrowly approved synthetic credential test-name
matches backed by the frozen public security test AST. That one public test source also
permits only matching credential-like bytes inside frozen string-literal AST spans.
The originals are preserved and every other byte was scanned.

There are 12 logical repositories and 36 independently frozen stage repositories.
`fixture-bundles/` includes all refs of each author-generated stage. Every reachable commit
must belong to the frozen canonical stage set; all reachable text blobs/commits are scanned
before bundling. No Git config, hooks, native-state or reflogs are copied.

Verify every member with MEMBER-MANIFEST.json and the external manifest's ZIP SHA256 before use.
`git bundle verify fixture-bundles/<task-id>.bundle` checks a bundle inside a temporary Git repo.
`git clone fixture-bundles/<task-id>.bundle <destination>` restores that stage's original commit/tree.

For an exact auditor rerun, use a disposable environment with the original artifact layout
`/workspace/Memglide/.local/warm-v2`. Copy `study/` contents there without modifying originals, and clone each
bundle into the repository path listed in study/metadata.json. Never overwrite a current study.
The original auditor at the runtime freeze remains in frozen-source/. Its initial audit
is retained even when an interrupted projection needs conservative post-study handling.
The separately pinned post-study-auditor/ version preserves raw observations while keeping
unattested complete-attempt usage/cost unknown; it does not change attempts or grades.
Run Python from post-study-auditor/:

    python -m benchmarks.audit_warm --report /workspace/Memglide/.local/warm-v2/report.json --artifact-root /workspace/Memglide/.local/warm-v2 --output /tmp/warm-audit-rerun

Original records retain absolute paths. The auditor rejects pointers outside its explicit root;
use the original layout rather than rewriting result records or rehashing their ledger.
No authentication or model requests are required for these checks.

Excluded: native/Codex state, authentication, device-login codes, environment dumps, worktrees,
databases/WAL/SHM, untracked tar archives, installed environments, caches and live credentials.
Pattern scanning is a precaution, not proof that every possible secret format can be detected.
